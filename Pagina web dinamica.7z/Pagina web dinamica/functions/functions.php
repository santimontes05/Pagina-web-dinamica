<?php

if(isset($_POST['submint']));{

    $user = $_POST['user'];
    $pass = $_POST ['pass'];
    $userDB = "pedro@gmail.com";
    $passDb = "123";

    if (isset($_POST['user'])) {

        if ($user=== $userDB) {
            header("location: ../home.php");

        }
        else{
        echo '<script language="javascript" >alert("error en datos");</script>';
        }
    }
}